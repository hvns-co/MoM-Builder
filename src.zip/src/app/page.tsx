import SheetMetalPricer from "@/components/sheet-metal-pricer";

export default function Home() {
  return (
    <main>
      <SheetMetalPricer />
    </main>
  );
}
